# `querystring` for Sketch

All the [nodejs querystring](https://nodejs.org/api/querystring.html) API is available.
